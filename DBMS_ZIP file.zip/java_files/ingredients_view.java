import java.sql.*;
import javax.swing.table.DefaultTableModel;
public class ingredients_view extends javax.swing.JFrame {
ResultSet rs;

    public ingredients_view() {
        
        dbconnect();
        initComponents();
        putData();
        
    }
    @SuppressWarnings("unchecked")
                           
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        IngredientsTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("View of ingredients details");

        IngredientsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Food id",  "Ingredient Name" , "grading"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(IngredientsTable);
        if (IngredientsTable.getColumnModel().getColumnCount() > 0) {
            IngredientsTable.getColumnModel().getColumn(0).setResizable(false);
            IngredientsTable.getColumnModel().getColumn(1).setResizable(false);
            IngredientsTable.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }                       
void dbconnect()
    {
                    try{
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","leena","vasavi");
				Statement stmt=con.createStatement();
				
                                
                                 rs = stmt.executeQuery("select * from ingredients");
			}
			catch(ClassNotFoundException | NumberFormatException | SQLException e){
				System.out.println("Error Occured!!"+e);
			}
    }
void putData() 
    {
        try
        {
        DefaultTableModel model = (DefaultTableModel) IngredientsTable.getModel();
        String fid,ingname,grading;
        while(rs.next())
        {
            fid = rs.getString(1);
            ingname = rs.getString(2);
            grading = rs.getString(3);
            
            String rowData[]={fid,ingname,grading};
            model.addRow(rowData);
        }
        }
         catch(Exception e)
        {
            
        }
    }

   public static void main(String args[]) {
  
        java.awt.EventQueue.invokeLater(() -> {
            new ingredients_view().setVisible(true);
        });
    }

    private javax.swing.JTable IngredientsTable;
    private javax.swing.JScrollPane jScrollPane1;
}