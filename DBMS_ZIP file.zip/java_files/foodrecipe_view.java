import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class foodrecipe_view extends javax.swing.JFrame {
ResultSet rs;
   
    public foodrecipe_view() {
        dbconnect();
        initComponents();
        putData();
    }
    
    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        FoodrecipeTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("View of food recipe details");

        FoodrecipeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Food_id", "Customer_id", "Food Name"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(FoodrecipeTable);
        if (FoodrecipeTable.getColumnModel().getColumnCount() > 0) {
            FoodrecipeTable.getColumnModel().getColumn(0).setResizable(false);
            FoodrecipeTable.getColumnModel().getColumn(1).setResizable(false);
            FoodrecipeTable.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }                     
void dbconnect()
    {
                    try{
			
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","leena","vasavi");
				Statement stmt=con.createStatement();
				
                                
                                 rs = stmt.executeQuery("select * from food_recipe");
			}
			catch(ClassNotFoundException | NumberFormatException | SQLException e){
				System.out.println("Error Occured!!"+e);
			}
    }
void putData()
    {
        try
        {
        DefaultTableModel model = (DefaultTableModel) FoodrecipeTable.getModel();
        String fid,uid,fname;
        while(rs.next())
        {
            fid = rs.getString(1);
            uid = rs.getString(2);
            fname = rs.getString(3);
            
            String rowData[]={fid,uid,fname};
            model.addRow(rowData);
        }
        }
        
        catch(Exception e)
        {
            
        }
    }
  
    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(foodrecipe_view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(foodrecipe_view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(foodrecipe_view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(foodrecipe_view.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       
        java.awt.EventQueue.invokeLater(() -> {
            new foodrecipe_view().setVisible(true);
        });
    }
                 
    private javax.swing.JTable FoodrecipeTable;
    private javax.swing.JScrollPane jScrollPane1;
                   

 
}